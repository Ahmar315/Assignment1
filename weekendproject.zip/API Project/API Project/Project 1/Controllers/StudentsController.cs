﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Collections.Generic;
using Project_1.Models;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;

namespace Project_1.Controllers
{
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly string _connectionString;

        public StudentsController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }
        [HttpGet]
        [Route("getstudents")]
        public IActionResult GetAllStudents() 
        {
            List<Student> liststudents = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetAllStudents", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Student student = new Student();
                        student.Id = Convert.ToInt32(reader["ID"]);
                        student.FirstName = reader["FirstName"].ToString();
                        student.LastName = reader["LastName"].ToString();
                        student.Age = (int)reader["Age"];
                        if (reader["CourseID"].ToString()=="")
                        {
                            student.CourseId = 0;
                        }
                        else
                        {
                            student.CourseId = (int)(reader["CourseID"]);
                        }
                        liststudents.Add(student);
                    }
                }
            }
            return Ok(liststudents);
        }

        [HttpPost]
        [Route("addstudents")]
        public IActionResult AddStudent(Student student)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("AddStudents", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Firstname", student.FirstName);
                    command.Parameters.AddWithValue("@Lastname", student.LastName);
                    command.Parameters.AddWithValue("@Age", student.Age);
                    command.Parameters.AddWithValue("@CourseID", student.CourseId);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return Ok("Student added successfully");
        }
        [Route("deletestudent/{id}")]
        [HttpDelete]
        public IActionResult DeleteStudentbyId(int id)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("DeleteStudent", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@ID", id);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
                return Ok("Student deleted successfully");
            
        }
        [HttpPut]
        [Route("updatestudent")]
        public IActionResult UpdateStudent(Student student)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("UpdateStudents", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@ID", student.Id);
                    command.Parameters.AddWithValue("@NewAge", student.Age);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return Ok("Student update successfully");
        }
        [HttpGet]
        [Route("getstudentsbyage/{Age}")]
        public IActionResult GetStudentsByAge(int Age)
        {
            List<Student> liststudents = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetStudentsByAge", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Age",Age);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Student student = new Student();
                        student.Id = Convert.ToInt32(reader["ID"]);
                        student.FirstName = reader["FirstName"].ToString();
                        student.LastName = reader["LastName"].ToString();
                        student.Age = (int)reader["Age"];
                        if (reader["CourseID"].ToString() == "")
                        {
                            student.CourseId = 0;
                        }
                        else
                        {
                            student.CourseId = (int)(reader["CourseID"]);
                        }
                        liststudents.Add(student);
                    }
                }
            }
            return Ok(liststudents);
        }
        [HttpGet]
        [Route("getstudentsbycourse/{CourseID}")]
        public IActionResult GetStudentsByCourse(int CourseID)
        {
            List<Student> liststudents = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetStudentsByCourseID", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", CourseID);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Student student = new Student();
                        student.Id = Convert.ToInt32(reader["ID"]);
                        student.FirstName = reader["FirstName"].ToString();
                        student.LastName = reader["LastName"].ToString();
                        student.Age = (int)reader["Age"];
                        if (reader["CourseID"].ToString() == "")
                        {
                            student.CourseId = 0;
                        }
                        else
                        {
                            student.CourseId = (int)(reader["CourseID"]);
                        }
                        liststudents.Add(student);
                    }
                }
            }
            return Ok(liststudents);
        }

    }
}
