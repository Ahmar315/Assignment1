﻿using System;

namespace Assignment2
{  //This program will print the triangle pattern
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number");
            int Number = int.Parse(Console.ReadLine());
            for(int i=1; i <= Number; i++)
            {
                for(int j=i;j<=Number;j++)
                {
                    Console.Write(" ");
                }
                
                for (int k=1; k <= i;k++)
                    {
                        Console.Write("*");
                    }
                for (int l = 2; l <= i; l++)
                    Console.Write("*");
                Console.WriteLine();
            }
            {

            }
        }
    }
}
