﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numArray = {1,2,7,8,6};
            Console.Write("Enter the number to search =");
            int Number = int.Parse(Console.ReadLine());
            for(int i = 0; i < numArray.Length; i++)
            {
                if (numArray[i] == Number)
                {
                    Console.WriteLine("The entered number is in the array");
                    Console.ReadLine();
                    return;
                } 
            }
            Console.WriteLine("The entered number is not in array");
            Console.ReadLine();
        }
    }
}
