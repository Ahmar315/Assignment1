﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Task 11
// 
namespace Assignment2
{
    internal class Program
    {          
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Name");
           string Name = Console.ReadLine();
            bool IsPalindrom = true;
            for(int i=0; i<Name.Length; i++)
            {
                if (Name[i] != Name[Name.Length - i-1])
                {
                  IsPalindrom = false; 
                    break;  
                }
            }
            if(IsPalindrom) {
                Console.WriteLine("This is Palindrom");
            }
            else
            { Console.WriteLine("This is Not Palindrom");
            }
           Console.ReadLine();  
        }
    }
}
