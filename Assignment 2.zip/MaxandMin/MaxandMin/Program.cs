﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxandMin
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] unsortedArray = { 1, 4, 6, 9, 80, -9, -11, 45, 69, -96 };
            int MaxNum = unsortedArray[0];
            int MinNum = unsortedArray[0];
            for (int i = 1; i < unsortedArray.Length; i++)
            {
                if (unsortedArray[i] > MaxNum)
                {
                    MaxNum = unsortedArray[i];
                }
                if (unsortedArray[i] < MinNum)
                {
                    MinNum = unsortedArray[i];
                }
            }
            Console.WriteLine("Maximum number is : " + MaxNum);
            Console.WriteLine("Minimum number is : " + MinNum);
            Console.ReadLine(); 
        }
    }
}
