﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortedArray
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] unsorted = { 76, 56, 89, 34, 22, 69 };
            int MinValue = unsorted[0];
            for (int i = 0; i<unsorted.Length; i++)
            {
                for(int j = i+1; j<unsorted.Length; j++) {
                    if (unsorted[j] >unsorted[i])
                    {
                        MinValue= unsorted[j];
                        unsorted[j] = unsorted[i];
                        unsorted[i] = MinValue;
                    }
                }
            }
            for(int i = 0;i<unsorted.Length; i++)
            {
                Console.WriteLine(unsorted[i]);
            }
            Console.ReadLine();
        }
    }
}
