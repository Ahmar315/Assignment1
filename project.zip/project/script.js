// Students array
//var students = [];

// Courses array
//var courses = [];

//document.getElementById("firstName").val();   without jquery
// Add Student
function addStudent() {
    var firstname = $('#firstName').val();
	var lastname = $('#lastName').val();
    var age = $('#studentAge').val();
    var courseID = $('#studentcourseID').val();

    var student = {
        firstName: firstname,
		lastName: lastname,
        age: age,
        courseId: courseID
    };

    $.ajax({
        url: "http://localhost:58648/addstudents",
        type: "POST",
        data:JSON.stringify(student),
        contentType: 'application/json',
        success:function(data){
            alert(data),
            $('#studentForm')[0].reset();
            getStudents()
        }
    })
}

// Add Course
function addCourse() {
    var ID = $('#courseID').val();
    var name = $('#courseName').val();


    var course = {
        courseID: ID,
        courseName: name
    };

    //courses.push(course);
    $.ajax({
        url: "http://localhost:58648/addcourse",
        type: "POST",
        data:JSON.stringify(course),
        contentType: 'application/json',
        success:function(data){
            alert(data),
            $('#courseForm')[0].reset();
            getCourses()
        }
    })
}


//ajax
function getStudents(){
    $.ajax({
        url:"http://localhost:58648/getstudents",
        type:'GET',
        success:function(data){
            $('#studentList').empty();
            data.forEach(function(student) {
                $('#studentList').append('<li>' + student.firstName + ', ' + student.lastName + ', ' + student.age + ', ' + student.courseId +'</li>');
            });
        }
    })
}


function getCourses(){
    $.ajax({
        url:"http://localhost:58648/getcourses",
        type:'GET',
        success:function(data){
            $('#courseList').empty();
            data.forEach(function(course) {
                $('#courseList').append('<tr>' +'<td>'+ course.courseID+'</td>' + ', ' +'<td>'+ course.courseName+'</td>' +'<td>'+ "<button class='btn btn-primary' onclick='deletecourse("+course.courseID+")' >Delete</button>"+'</td>' +'</tr>');
            });
        }
    })
}

function deletecourse(id){
    if(confirm("Are you sure, you want to delete this?")){
        $.ajax({
            url:"http://localhost:58648/deletecourse/"+id,
            type:'DELETE',
            success:function(data){
                alert(data);
                getCourses();
            }
        })
    }

}

//on page load
$(document).ready(function() {
    getStudents();
    getCourses();
});