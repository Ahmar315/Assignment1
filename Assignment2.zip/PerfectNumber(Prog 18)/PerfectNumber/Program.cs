﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerfectNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the Number: ");
            int Number = Convert.ToInt32(Console.ReadLine());
            int Sum = 0;
            int Reminder;
            for(int i=1; i<Number; i++)
            {
                Reminder = Number % i;
                if (Reminder == 0)
                {
                    Sum = Sum + i;
                }
            }
            if (Sum == Number)
            {
                Console.WriteLine("The Entered Number is Perfect.");
            }
            else
            {
                Console.WriteLine("The Entered Number is not Perfect.");
            }
            Console.ReadLine();
        }
    }
}
