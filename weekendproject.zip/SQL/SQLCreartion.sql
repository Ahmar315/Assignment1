-- Create Database
CREATE DATABASE DemoDB;
GO

USE DemoDB;
GO