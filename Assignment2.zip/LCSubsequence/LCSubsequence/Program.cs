﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LCSubsequence
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter string 1: ");
            Console.WriteLine();
        }
    }
}
