﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReverseWord
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any Number/Name");
            string Name = Console.ReadLine();
            string reverse = null;
            for(int i=Name.Length-1; i>=0; i--) 
            { 
             reverse += Name[i];
            }
            Console.WriteLine(reverse);
            Console.ReadLine(); 
        }
    }
}
