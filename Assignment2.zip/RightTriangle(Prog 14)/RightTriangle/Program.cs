﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RightTriangle
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number");
            int Num = Convert.ToInt32(Console.ReadLine());  
            for(int i = 0; i < Num; i++)
            {
                for(int j = 0; j <=i; j++)
                {
                Console.Write("*");    
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
