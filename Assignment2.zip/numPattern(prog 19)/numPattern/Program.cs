﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace numPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any number =");
            int Num = int.Parse(Console.ReadLine());
            for (int i = 0; i < Num; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    Console.Write(j+1);

                }
                Console.WriteLine();

            }
            Console.ReadLine();
        }
    }
}
