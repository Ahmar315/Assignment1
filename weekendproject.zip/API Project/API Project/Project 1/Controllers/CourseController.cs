﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Project_1.Models;
using System.Data;


namespace Project_1.Controllers
{
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly string _connectionString;

        public CourseController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }
        [HttpGet]
        [Route("getcourses")]
        public IActionResult GetAllCourses()
        {
            List<Course> listcourses = new List<Course>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetAllCourses", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Course course = new Course();
                        course.CourseID = Convert.ToInt32(reader["CourseID"]);
                        course.CourseName = reader["CourseName"].ToString();
                        listcourses.Add(course);
                    }
                }
            }
            return Ok(listcourses);
        }


        [HttpPost]
        [Route("AddCourse")]
        public IActionResult AddCourse(Course course)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("AddCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@CourseID", course.CourseID);
                    command.Parameters.AddWithValue("@CourseName", course.CourseName);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return Ok("Course added successfully");
        }

        [Route("deletecourse/{CourseID}")]
        [HttpDelete]
        public IActionResult DeleteCoursebyCourseId(int CourseID)
        {
            int res = 0;
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("DeleteCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", CourseID);
                    connection.Open();
                    res = command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return Ok("Course deleted successfully");
        }

        [HttpPut]
        [Route("updatecourse")]
        public IActionResult UpdateCourse(Course course)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("UpdateCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", course.CourseID);
                    command.Parameters.AddWithValue("@NewCourseName", course.CourseName);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return Ok("Course update successfully");
        }
        [HttpGet]
        [Route("getpopularcourse")]
        public IActionResult GetPopularCourse()
        {
            List<Course> listcourses = new List<Course>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("PopularCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Course course = new Course();
                        course.CourseID = Convert.ToInt32(reader["CourseID"]);
                        course.CourseName = reader["CourseName"].ToString();
                        listcourses.Add(course);
                    }
                }
            }
            return Ok(listcourses);
        }
    }
}

